import mysql.connector

def conectar_banco():
    conexao = mysql.connector.connect(
        host='localhost',
        user='root',
        password='Raellu1z',
        database='crudbd',
    )
    return conexao

def criar_contato(cursor):
    nome_contato = input("Digite o nome do contato: ")
    telefone = input("Digite o telefone do contato: ")
    comando_insert = f'INSERT INTO agenda (nome_contato, telefone) VALUES ("{nome_contato}", "{telefone}")'
    cursor.execute(comando_insert)
    print("Contato adicionado com sucesso!")

def listar_contatos(cursor):
    comando_select = 'SELECT * FROM agenda'
    cursor.execute(comando_select)
    contatos = cursor.fetchall()
    print("Lista de Contatos:")
    for contato in contatos:
        print(contato)

def atualizar_contato(cursor):
    nome_contato = input("Digite o nome do contato que deseja atualizar: ")
    novo_telefone = input("Digite o novo telefone: ")
    comando_update = f'UPDATE agenda SET telefone = "{novo_telefone}" WHERE nome_contato = "{nome_contato}"'
    cursor.execute(comando_update)
    print("Contato atualizado com sucesso!")

def deletar_contato(cursor):
    nome_contato = input("Digite o nome do contato que deseja excluir: ")
    comando_delete = f'DELETE FROM agenda WHERE nome_contato = "{nome_contato}"'
    cursor.execute(comando_delete)
    print("Contato excluído com sucesso!")

def main():
    conexao = conectar_banco()
    cursor = conexao.cursor()

    while True:
        print("\nEscolha uma opção:")
        print("1. Criar contato")
        print("2. Listar contatos")
        print("3. Atualizar contato")
        print("4. Deletar contato")
        print("5. Sair")

        opcao = input("Digite o número da opção desejada: ")

        if opcao == '1':
            criar_contato(cursor)
        elif opcao == '2':
            listar_contatos(cursor)
        elif opcao == '3':
            atualizar_contato(cursor)
        elif opcao == '4':
            deletar_contato(cursor)
        elif opcao == '5':
            break
        else:
            print("Opção inválida!")

        conexao.commit()  # Confirmar as alterações no banco de dados após cada operação

    cursor.close()
    conexao.close()

if __name__ == "__main__":
    main()